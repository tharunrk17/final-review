export default function SectionHeader({ title, description, action }) { return <div className="section-head"><div><h2>{title}</h2><p>{description}</p></div>{action}</div>; }
