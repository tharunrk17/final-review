import { useEffect, useState } from 'react';
import { 
  AlertTriangle, 
  CheckCircle2, 
  Droplets, 
  HelpCircle, 
  Recycle, 
  ShieldAlert, 
  TrendingDown, 
  TrendingUp, 
  Minus, 
  ArrowUpRight,
  Info,
  Waves
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  CartesianGrid, 
  Cell, 
  Legend, 
  LineChart, 
  Line, 
  ResponsiveContainer, 
  Tooltip, 
  XAxis, 
  YAxis 
} from 'recharts';
import api from '../lib/api.js';
import { Link } from 'react-router-dom';

const SOURCE_COLORS = {
  'Plastic': '#2563eb',
  'Industrial Discharge': '#ea580c',
  'Oil Spill': '#dc2626',
  'Other': '#7c3aed'
};

const STATUS_COLORS = {
  'Reported': '#ef4444',
  'Investigating': '#f59e0b',
  'Cleanup Planned': '#3b82f6',
  'Resolved': '#10b981'
};

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/dashboard')
      .then(res => setData(res.data))
      .catch(err => console.error('Dashboard load error', err))
      .finally(() => setLoading(false));
  }, []);

  if (loading || !data) {
    return (
      <div className="loading-block">
        <div className="spinner" />
        <p>Loading real-time marine analytics…</p>
      </div>
    );
  }

  const { summary, reportsByType, reportsByStatus, waterTrends, recentCleanups } = data;
  const trend = summary?.trend30Day || { trend: 'Stable', recentAvgDO: 6.8, priorAvgDO: 6.0 };

  const getTrendIcon = (t) => {
    if (t === 'Improving') return <TrendingUp size={20} className="text-success" />;
    if (t === 'Worsening') return <TrendingDown size={20} className="text-danger" />;
    return <Minus size={20} className="text-warning" />;
  };

  const getTrendBadgeClass = (t) => {
    if (t === 'Improving') return 'trend-badge improving';
    if (t === 'Worsening') return 'trend-badge worsening';
    return 'trend-badge stable';
  };

  return (
    <div className="dashboard-container">
      {/* Hero Welcome Banner */}
      <div className="hero-banner">
        <div>
          <div className="eyebrow">COASTAL ECOSYSTEM MONITOR · EVIDENCE DASHBOARD</div>
          <h2>Marine Pollution Control & Recovery Center</h2>
          <p>
            Real-time multi-source data uniting citizen field reports, aquatic lab sensors, and NGO cleanup operations.
          </p>
        </div>
        <div className="hero-badge-box">
          <div className="hero-trend-pill">
            <span className="dot pulse" />
            <span>30-Day DO Status: <strong>{trend.trend}</strong></span>
          </div>
          <small>Avg DO: {trend.recentAvgDO} mg/L (vs {trend.priorAvgDO} mg/L prior)</small>
        </div>
      </div>

      {/* 4 Required Summary Cards */}
      <div className="summary-grid">
        {/* Card 1: Total Reports */}
        <div className="summary-card">
          <div className="card-top">
            <span className="card-label">Total Reports</span>
            <div className="icon-wrapper blue">
              <ShieldAlert size={20} />
            </div>
          </div>
          <div className="card-val">{summary.totalReports}</div>
          <div className="card-sub">
            All recorded pollution events across coastal zones
          </div>
        </div>

        {/* Card 2: Percentage Resolved */}
        <div className="summary-card">
          <div className="card-top">
            <span className="card-label">Resolution Rate</span>
            <div className="icon-wrapper green">
              <CheckCircle2 size={20} />
            </div>
          </div>
          <div className="card-val">{summary.percentageResolved}%</div>
          <div className="card-sub">
            {summary.resolvedReports} of {summary.totalReports} incidents contained & resolved
          </div>
        </div>

        {/* Card 3: Total Waste Collected in KG */}
        <div className="summary-card">
          <div className="card-top">
            <span className="card-label">Total Waste Collected</span>
            <div className="icon-wrapper purple">
              <Recycle size={20} />
            </div>
          </div>
          <div className="card-val">{summary.totalWasteKg.toLocaleString()} <small>kg</small></div>
          <div className="card-sub">
            Includes {summary.totalPlasticKg} kg plastic & {summary.totalOilLitres} L oil recovered
          </div>
        </div>

        {/* Card 4: 30-Day Water Quality Trend */}
        <div className="summary-card trend-card">
          <div className="card-top">
            <span className="card-label">30-Day DO Trend</span>
            <div className="icon-wrapper teal">
              <Droplets size={20} />
            </div>
          </div>
          <div className="trend-row">
            <div className="card-val">{trend.trend}</div>
            <div className={getTrendBadgeClass(trend.trend)}>
              {getTrendIcon(trend.trend)}
              <span>{trend.difference > 0 ? `+${trend.difference}` : trend.difference} mg/L</span>
            </div>
          </div>
          <div className="card-sub">
            Based on Dissolved Oxygen (DO) avg over past 30 days vs previous 30 days
          </div>
        </div>
      </div>

      {/* Reports Breakdown Charts Row */}
      <div className="charts-double-grid">
        {/* Chart 1: Reports by Type */}
        <div className="panel chart-panel">
          <div className="panel-header">
            <div>
              <h3>Reports by Pollution Type</h3>
              <p>Breakdown across plastic waste, industrial effluents, and oil slicks.</p>
            </div>
          </div>
          <div className="chart-wrapper">
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={reportsByType} margin={{ top: 20, right: 20, left: -10, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="name" tick={{ fontSize: 12, fill: '#64748b' }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 12, fill: '#64748b' }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', color: '#fff', borderRadius: '8px' }} 
                  itemStyle={{ color: '#38bdf8' }}
                />
                <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                  {reportsByType.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={SOURCE_COLORS[entry.name] || '#3b82f6'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="chart-legend-custom">
            {reportsByType.map(t => (
              <span key={t.name} className="legend-chip">
                <span className="legend-color-dot" style={{ backgroundColor: SOURCE_COLORS[t.name] || '#3b82f6' }} />
                {t.name}: <strong>{t.count}</strong>
              </span>
            ))}
          </div>
        </div>

        {/* Chart 2: Reports by Status */}
        <div className="panel chart-panel">
          <div className="panel-header">
            <div>
              <h3>Reports by Status Stage</h3>
              <p>Operational incident lifecycle from initial filing to resolution.</p>
            </div>
          </div>
          <div className="chart-wrapper">
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={reportsByStatus} margin={{ top: 20, right: 20, left: -10, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="name" tick={{ fontSize: 12, fill: '#64748b' }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 12, fill: '#64748b' }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', color: '#fff', borderRadius: '8px' }} 
                />
                <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                  {reportsByStatus.map((entry, index) => (
                    <Cell key={`status-${index}`} fill={STATUS_COLORS[entry.name] || '#64748b'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="chart-legend-custom">
            {reportsByStatus.map(s => (
              <span key={s.name} className="legend-chip">
                <span className="legend-color-dot" style={{ backgroundColor: STATUS_COLORS[s.name] || '#64748b' }} />
                {s.name}: <strong>{s.count}</strong>
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Water Quality Multi-Line Chart */}
      <div className="panel full-width-panel">
        <div className="panel-header">
          <div>
            <h3>Water Quality Trends Over Time</h3>
            <p>Chronological tracking of pH, Dissolved Oxygen (mg/L), Turbidity (NTU), and Temperature (°C).</p>
          </div>
          <Link to="/water-quality" className="panel-link-btn">
            View All Station Logs <ArrowUpRight size={16} />
          </Link>
        </div>
        <div className="chart-wrapper large-chart">
          <ResponsiveContainer width="100%" height={320}>
            <LineChart data={waterTrends} margin={{ top: 15, right: 30, left: 0, bottom: 25 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
              <XAxis dataKey="date" tick={{ fontSize: 12, fill: '#64748b' }} />
              <YAxis tick={{ fontSize: 12, fill: '#64748b' }} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#f8fafc', borderRadius: '8px' }} 
              />
              <Legend verticalAlign="top" height={36} />
              <Line 
                type="monotone" 
                name="Dissolved Oxygen (mg/L)" 
                dataKey="dissolvedOxygen" 
                stroke="#0284c7" 
                strokeWidth={3} 
                dot={{ r: 5 }} 
              />
              <Line 
                type="monotone" 
                name="pH Level" 
                dataKey="ph" 
                stroke="#10b981" 
                strokeWidth={2} 
                dot={{ r: 4 }} 
              />
              <Line 
                type="monotone" 
                name="Turbidity (NTU)" 
                dataKey="turbidity" 
                stroke="#f59e0b" 
                strokeWidth={2} 
                dot={{ r: 4 }} 
              />
              <Line 
                type="monotone" 
                name="Temperature (°C)" 
                dataKey="temperature" 
                stroke="#ef4444" 
                strokeWidth={2} 
                dot={{ r: 4 }} 
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Decision Maker Indicator Guide Section */}
      <div className="panel guide-panel">
        <div className="panel-header">
          <div className="guide-title">
            <Info size={20} className="text-primary" />
            <div>
              <h3>What Indicators Mean for Decision Makers</h3>
              <p>Scientific benchmarks that guide regulatory enforcement, NGO cleanup deployment, and coastal public health.</p>
            </div>
          </div>
        </div>

        <div className="indicator-explanation-grid">
          <div className="indicator-box">
            <div className="indicator-box-top">
              <span className="dot-indicator blue" />
              <h4>Dissolved Oxygen (DO)</h4>
            </div>
            <p className="benchmark">Target: &gt; 6.5 mg/L | Critical Hypoxia: &lt; 4.0 mg/L</p>
            <p className="desc">
              Vital sign of marine life. When levels drop below 4 mg/L, fish and benthic organisms suffocate, creating aquatic "dead zones". Rapid drops signal heavy organic decomposition or chemical contamination.
            </p>
          </div>

          <div className="indicator-box">
            <div className="indicator-box-top">
              <span className="dot-indicator amber" />
              <h4>Turbidity (NTU)</h4>
            </div>
            <p className="benchmark">Target: &lt; 5.0 NTU | Severe Siltation: &gt; 15.0 NTU</p>
            <p className="desc">
              Measures water clarity and suspended particulate matter. High turbidity blocks solar penetration, halting photosynthesis in seagrass and coral reefs while clogging fish gills.
            </p>
          </div>

          <div className="indicator-box">
            <div className="indicator-box-top">
              <span className="dot-indicator green" />
              <h4>pH Baseline</h4>
            </div>
            <p className="benchmark">Normal Seawater: 7.8 – 8.3 | Alarm: &lt; 7.4 or &gt; 8.8</p>
            <p className="desc">
              Marine life requires stable alkaline seawater. Lower pH signifies ocean acidification or illegal acidic industrial effluent discharge, which dissolves calcium carbonate shells in crustaceans and coral.
            </p>
          </div>

          <div className="indicator-box">
            <div className="indicator-box-top">
              <span className="dot-indicator red" />
              <h4>Water Temperature (°C)</h4>
            </div>
            <p className="benchmark">Baseline: 26°C – 29°C | Thermal Discharge: &gt; 32°C</p>
            <p className="desc">
              Warmer water holds less dissolved oxygen. Unnatural temperature spikes near outfalls trigger thermal stress, algae blooms, and widespread coral bleaching.
            </p>
          </div>
        </div>
      </div>

      {/* Quick Navigation Cards */}
      <div className="quick-actions-row">
        <div className="quick-card">
          <ShieldAlert size={24} className="text-primary" />
          <div>
            <h4>Geotagged Incident Map</h4>
            <p>Explore map markers color-coded by pollution type (Plastic, Industrial, Oil Spill).</p>
          </div>
          <Link to="/reports" className="button secondary">Open Incident Map</Link>
        </div>

        <div className="quick-card">
          <Recycle size={24} className="text-success" />
          <div>
            <h4>Cleanup Drives & Volunteer Hub</h4>
            <p>View scheduled operations, register as a volunteer, and review waste recovered.</p>
          </div>
          <Link to="/cleanup" className="button secondary">View Cleanups</Link>
        </div>
      </div>
    </div>
  );
}
