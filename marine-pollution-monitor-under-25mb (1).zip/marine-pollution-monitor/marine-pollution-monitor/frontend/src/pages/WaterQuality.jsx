import { useEffect, useState } from 'react';
import { 
  Plus, 
  Droplets, 
  Thermometer, 
  Activity, 
  Eye, 
  ShieldCheck, 
  AlertTriangle,
  Info,
  Calendar
} from 'lucide-react';
import api from '../lib/api.js';
import Modal from '../components/Modal.jsx';
import SectionHeader from '../components/SectionHeader.jsx';
import EmptyState from '../components/EmptyState.jsx';
import { useAuth } from '../lib/AuthContext.jsx';

const initialForm = {
  station: '',
  location: '',
  ph: 8.1,
  dissolvedOxygen: 6.8,
  turbidity: 4.5,
  temperature: 28.5,
  oilIndex: 0.5,
  microplasticCount: 45,
  qualityStatus: 'Good',
  notes: ''
};

export default function WaterQuality() {
  const { user } = useAuth();
  const [rows, setRows] = useState([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(initialForm);
  const [submitting, setSubmitting] = useState(false);

  const canRecord = ['officer', 'ngo', 'admin'].includes(user?.role);

  const loadData = () => {
    api.get('/water-quality')
      .then(r => setRows(r.data))
      .catch(err => console.error('Error fetching water quality data', err));
  };

  useEffect(() => {
    loadData();
  }, []);

  const save = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await api.post('/water-quality', {
        ...form,
        ph: Number(form.ph),
        dissolvedOxygen: Number(form.dissolvedOxygen),
        turbidity: Number(form.turbidity),
        temperature: Number(form.temperature),
        oilIndex: Number(form.oilIndex) || 0,
        microplasticCount: Number(form.microplasticCount) || 0
      });
      setOpen(false);
      setForm(initialForm);
      loadData();
    } catch (err) {
      alert(err.response?.data?.message || 'Error saving measurement');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="water-page-wrapper">
      <SectionHeader 
        title="Aquatic Water Quality Telemetry" 
        description="Continuous monitoring of physical and chemical parameters (pH, Dissolved Oxygen, Turbidity, Temperature) to evaluate ecological health."
        action={
          canRecord && (
            <button className="primary" onClick={() => setOpen(true)}>
              <Plus size={17} /> Record Station Data
            </button>
          )
        }
      />

      {/* Decision Maker Guidance Strip */}
      <div className="water-parameters-banner">
        <div className="param-guide-col">
          <strong>Dissolved Oxygen (DO):</strong>
          <span>Optimal: &gt; 6.5 mg/L | Stress: &lt; 4.0 mg/L</span>
        </div>
        <div className="param-guide-col">
          <strong>Turbidity:</strong>
          <span>Clear: &lt; 5.0 NTU | Polluted: &gt; 15.0 NTU</span>
        </div>
        <div className="param-guide-col">
          <strong>pH Range:</strong>
          <span>Baseline: 7.8 – 8.3 (Seawater buffering)</span>
        </div>
        <div className="param-guide-col">
          <strong>Temperature:</strong>
          <span>Tropical marine normal: 26°C – 29°C</span>
        </div>
      </div>

      {/* Stations Cards Grid */}
      <div className="quality-cards-grid">
        {rows.map(r => (
          <div className="quality-card" key={r._id}>
            <div className="quality-card-header">
              <div>
                <span className="station-code">{r.station}</span>
                <h3>{r.location}</h3>
              </div>
              <span className={`status status-${r.qualityStatus.toLowerCase()}`}>
                {r.qualityStatus}
              </span>
            </div>

            {/* Health Bar Meter */}
            <div className="health-meter-bar">
              <div 
                className={`health-meter-fill ${r.qualityStatus.toLowerCase()}`}
                style={{
                  width: `${r.qualityStatus === 'Good' ? 95 : r.qualityStatus === 'Watch' ? 65 : 35}%`
                }} 
              />
            </div>

            {/* Metric Parameter Grid */}
            <div className="metric-parameter-grid">
              <div className="param-box">
                <span className="param-name">Dissolved Oxygen</span>
                <strong className={`param-value ${r.dissolvedOxygen >= 6.5 ? 'text-success' : r.dissolvedOxygen < 4.5 ? 'text-danger' : 'text-warning'}`}>
                  {r.dissolvedOxygen} <small>mg/L</small>
                </strong>
              </div>

              <div className="param-box">
                <span className="param-name">pH Level</span>
                <strong className="param-value text-primary">
                  {r.ph}
                </strong>
              </div>

              <div className="param-box">
                <span className="param-name">Turbidity</span>
                <strong className={`param-value ${r.turbidity > 10 ? 'text-danger' : 'text-primary'}`}>
                  {r.turbidity} <small>NTU</small>
                </strong>
              </div>

              <div className="param-box">
                <span className="param-name">Temperature</span>
                <strong className="param-value text-primary">
                  {r.temperature} <small>°C</small>
                </strong>
              </div>
            </div>

            <div className="quality-card-footer">
              <div className="measured-date">
                <Calendar size={14} />
                <span>Sampled: {new Date(r.measuredAt).toLocaleDateString()}</span>
              </div>
              {r.notes && (
                <p className="card-notes">"{r.notes}"</p>
              )}
            </div>
          </div>
        ))}
      </div>

      {rows.length === 0 && <EmptyState text="No water quality station data logged yet." />}

      {/* New Measurement Modal */}
      {open && (
        <Modal title="Log Water Quality Station Measurement" onClose={() => setOpen(false)}>
          <form className="form-grid" onSubmit={save}>
            <label>
              Station Code
              <input 
                type="text" 
                value={form.station} 
                onChange={e => setForm({ ...form, station: e.target.value })} 
                placeholder="e.g. ST-05" 
                required 
              />
            </label>

            <label>
              Sampling Location
              <input 
                type="text" 
                value={form.location} 
                onChange={e => setForm({ ...form, location: e.target.value })} 
                placeholder="e.g. Marina Beach Outfall" 
                required 
              />
            </label>

            <label>
              pH Level (Normal: 7.8 - 8.3)
              <input 
                type="number" 
                step="0.01" 
                value={form.ph} 
                onChange={e => setForm({ ...form, ph: e.target.value })} 
                required 
              />
            </label>

            <label>
              Dissolved Oxygen (mg/L)
              <input 
                type="number" 
                step="0.1" 
                value={form.dissolvedOxygen} 
                onChange={e => setForm({ ...form, dissolvedOxygen: e.target.value })} 
                required 
              />
            </label>

            <label>
              Turbidity (NTU)
              <input 
                type="number" 
                step="0.1" 
                value={form.turbidity} 
                onChange={e => setForm({ ...form, turbidity: e.target.value })} 
                required 
              />
            </label>

            <label>
              Water Temperature (°C)
              <input 
                type="number" 
                step="0.1" 
                value={form.temperature} 
                onChange={e => setForm({ ...form, temperature: e.target.value })} 
                required 
              />
            </label>

            <label>
              Quality Assessment Status
              <select 
                value={form.qualityStatus} 
                onChange={e => setForm({ ...form, qualityStatus: e.target.value })}
              >
                <option value="Good">Good (Healthy marine baseline)</option>
                <option value="Watch">Watch (Elevated turbidity or marginal DO)</option>
                <option value="Poor">Poor (Severe hypoxia or effluent contamination)</option>
              </select>
            </label>

            <label className="span-2">
              Field Observations & Lab Notes
              <textarea 
                rows="3" 
                value={form.notes} 
                onChange={e => setForm({ ...form, notes: e.target.value })} 
                placeholder="Describe tidal flow, surface odor, proximity to drains…" 
              />
            </label>

            <div className="modal-actions span-2">
              <button type="button" className="secondary" onClick={() => setOpen(false)}>
                Cancel
              </button>
              <button className="primary" disabled={submitting}>
                {submitting ? 'Saving…' : 'Record Measurement'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
