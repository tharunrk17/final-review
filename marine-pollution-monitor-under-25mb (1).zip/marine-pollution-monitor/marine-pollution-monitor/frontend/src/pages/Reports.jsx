import { useEffect, useState } from 'react';
import { 
  Plus, 
  Search, 
  Trash2, 
  MapPin, 
  Filter, 
  ExternalLink, 
  ShieldAlert, 
  Eye, 
  Check, 
  Camera,
  Layers,
  ChevronDown
} from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import api from '../lib/api.js';
import Modal from '../components/Modal.jsx';
import SectionHeader from '../components/SectionHeader.jsx';
import EmptyState from '../components/EmptyState.jsx';
import { useAuth } from '../lib/AuthContext.jsx';

// Color map for pollution types
const TYPE_COLORS = {
  'Plastic': '#2563eb',             // Blue
  'Industrial Discharge': '#ea580c', // Orange
  'Oil Spill': '#dc2626',            // Red
  'Other': '#7c3aed'                 // Purple
};

// Create custom pin icons using L.divIcon
function createPinIcon(source = 'Plastic') {
  const color = TYPE_COLORS[source] || '#2563eb';
  return L.divIcon({
    className: 'custom-leaflet-marker',
    html: `
      <div style="
        background-color: ${color};
        width: 32px;
        height: 32px;
        border-radius: 50% 50% 50% 0;
        transform: rotate(-45deg);
        border: 2px solid #ffffff;
        box-shadow: 0 4px 10px rgba(0,0,0,0.3);
        display: flex;
        align-items: center;
        justify-content: center;
      ">
        <div style="
          width: 10px;
          height: 10px;
          background: #ffffff;
          border-radius: 50%;
        "></div>
      </div>
    `,
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -28]
  });
}

// Click listener to pick GPS coordinates from the map
function MapClickSetter({ onMapClick }) {
  useMapEvents({
    click(e) {
      onMapClick(Number(e.latlng.lat.toFixed(5)), Number(e.latlng.lng.toFixed(5)));
    }
  });
  return null;
}

const initialForm = {
  title: '',
  source: 'Plastic',
  severity: 'Medium',
  location: '',
  latitude: 13.0500,
  longitude: 80.2824,
  description: '',
  imageUrl: '',
  status: 'Reported'
};

const SAMPLE_IMAGES = [
  { label: 'Plastic debris', url: 'https://images.unsplash.com/photo-1618477461853-cf6ed80faba5?auto=format&fit=crop&w=600&q=80' },
  { label: 'Industrial outfall', url: 'https://images.unsplash.com/photo-1611273426858-450d8e3c9fce?auto=format&fit=crop&w=600&q=80' },
  { label: 'Oil slick', url: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=600&q=80' },
  { label: 'Ghost nets', url: 'https://images.unsplash.com/photo-1621451537084-482c73073a0f?auto=format&fit=crop&w=600&q=80' }
];

export default function Reports() {
  const { user } = useAuth();
  const [rows, setRows] = useState([]);
  const [search, setSearch] = useState('');
  const [filterSource, setFilterSource] = useState('All');
  const [filterSeverity, setFilterSeverity] = useState('All');
  const [filterStatus, setFilterStatus] = useState('All');
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(initialForm);
  const [saving, setSaving] = useState(false);
  const [selectedReport, setSelectedReport] = useState(null);
  const [statusUpdating, setStatusUpdating] = useState(null);

  const canManageStatus = ['officer', 'admin', 'ngo'].includes(user?.role);
  const canDelete = user?.role === 'admin';

  const load = () => {
    api.get('/reports', {
      params: {
        search,
        source: filterSource,
        severity: filterSeverity,
        status: filterStatus
      }
    })
    .then(r => setRows(r.data))
    .catch(err => console.error('Error fetching reports', err));
  };

  useEffect(() => {
    load();
  }, [search, filterSource, filterSeverity, filterStatus]);

  const handleMapClick = (lat, lng) => {
    setForm(prev => ({
      ...prev,
      latitude: lat,
      longitude: lng,
      location: prev.location || `Coast (${lat}, ${lng})`
    }));
  };

  const save = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.post('/reports', {
        ...form,
        latitude: Number(form.latitude),
        longitude: Number(form.longitude)
      });
      setOpen(false);
      setForm(initialForm);
      load();
    } catch (err) {
      alert(err.response?.data?.message || 'Error saving report');
    } finally {
      setSaving(false);
    }
  };

  const updateStatus = async (id, newStatus) => {
    setStatusUpdating(id);
    try {
      await api.patch(`/reports/${id}/status`, { status: newStatus });
      load();
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to update status');
    } finally {
      setStatusUpdating(null);
    }
  };

  const remove = async (id) => {
    if (confirm('Are you sure you want to permanently delete this report?')) {
      await api.delete('/reports/' + id);
      load();
    }
  };

  // Center map around first report or Chennai baseline
  const mapCenter = rows.length > 0 ? [rows[0].latitude, rows[0].longitude] : [13.0500, 80.2824];

  return (
    <div className="reports-page-wrapper">
      <SectionHeader 
        title="Marine Pollution Reports & Geotagged Map" 
        description="Georeferenced incident tracking across coastal zones with severity levels and operational lifecycle statuses."
        action={
          <button className="primary" onClick={() => setOpen(true)}>
            <Plus size={17} /> Report Pollution Incident
          </button>
        }
      />

      {/* Map Legend Banner */}
      <div className="map-legend-bar">
        <div className="legend-items">
          <span className="legend-label"><Layers size={16} /> Marker Color Key:</span>
          <span className="map-legend-chip">
            <span className="dot-pin" style={{ backgroundColor: TYPE_COLORS['Plastic'] }} />
            Plastic Debris
          </span>
          <span className="map-legend-chip">
            <span className="dot-pin" style={{ backgroundColor: TYPE_COLORS['Industrial Discharge'] }} />
            Industrial Discharge
          </span>
          <span className="map-legend-chip">
            <span className="dot-pin" style={{ backgroundColor: TYPE_COLORS['Oil Spill'] }} />
            Oil Spill
          </span>
          <span className="map-legend-chip">
            <span className="dot-pin" style={{ backgroundColor: TYPE_COLORS['Other'] }} />
            Other Pollutants
          </span>
        </div>
        <div className="map-hint">
          Click any marker on the map to inspect details
        </div>
      </div>

      {/* Interactive Leaflet Map */}
      <div className="map-container-card">
        <MapContainer 
          center={mapCenter} 
          zoom={9} 
          scrollWheelZoom={true} 
          className="leaflet-map"
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          <MapClickSetter onMapClick={handleMapClick} />
          {rows.map(r => (
            <Marker 
              key={r._id} 
              position={[r.latitude, r.longitude]} 
              icon={createPinIcon(r.source)}
            >
              <Popup className="incident-popup">
                <div className="popup-card">
                  {r.imageUrl && (
                    <img src={r.imageUrl} alt={r.title} className="popup-img" />
                  )}
                  <h4>{r.title}</h4>
                  <div className="popup-tags">
                    <span className="tag source" style={{ backgroundColor: TYPE_COLORS[r.source], color: '#fff' }}>
                      {r.source}
                    </span>
                    <span className={`tag severity-${r.severity.toLowerCase()}`}>
                      {r.severity} Severity
                    </span>
                    <span className={`status status-${r.status.toLowerCase().replace(' ', '-')}`}>
                      {r.status}
                    </span>
                  </div>
                  <p className="popup-loc"><MapPin size={13} /> {r.location}</p>
                  <p className="popup-desc">{r.description}</p>
                  <small>GPS: {r.latitude.toFixed(4)}, {r.longitude.toFixed(4)}</small>
                </div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>
      </div>

      {/* Filter and Search Bar */}
      <div className="filters-card">
        <div className="search-box">
          <Search size={18} />
          <input 
            type="text" 
            value={search} 
            onChange={e => setSearch(e.target.value)} 
            placeholder="Search by incident title, location, or notes…" 
          />
        </div>

        <div className="filter-group">
          <label>
            Type:
            <select value={filterSource} onChange={e => setFilterSource(e.target.value)}>
              <option value="All">All Types</option>
              <option value="Plastic">Plastic</option>
              <option value="Industrial Discharge">Industrial Discharge</option>
              <option value="Oil Spill">Oil Spill</option>
              <option value="Other">Other</option>
            </select>
          </label>

          <label>
            Severity:
            <select value={filterSeverity} onChange={e => setFilterSeverity(e.target.value)}>
              <option value="All">All Severities</option>
              <option value="Low">Low</option>
              <option value="Medium">Medium</option>
              <option value="High">High</option>
            </select>
          </label>

          <label>
            Status:
            <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
              <option value="All">All Statuses</option>
              <option value="Reported">Reported</option>
              <option value="Investigating">Investigating</option>
              <option value="Cleanup Planned">Cleanup Planned</option>
              <option value="Resolved">Resolved</option>
            </select>
          </label>
        </div>

        <span className="results-count">{rows.length} incident records</span>
      </div>

      {/* Reports Table with Action Controls */}
      <div className="table-panel">
        <table>
          <thead>
            <tr>
              <th>Incident & Evidence</th>
              <th>Source Type</th>
              <th>Severity</th>
              <th>Location & GPS</th>
              <th>Operational Status</th>
              <th>Date Filed</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(r => (
              <tr key={r._id}>
                <td>
                  <div className="incident-cell">
                    {r.imageUrl && (
                      <img src={r.imageUrl} alt={r.title} className="thumb-preview" />
                    )}
                    <div>
                      <strong>{r.title}</strong>
                      <span className="cell-sub">{r.description.slice(0, 65)}{r.description.length > 65 ? '…' : ''}</span>
                    </div>
                  </div>
                </td>
                <td>
                  <span className="tag source-badge" style={{ borderColor: TYPE_COLORS[r.source], color: TYPE_COLORS[r.source] }}>
                    {r.source}
                  </span>
                </td>
                <td>
                  <span className={`tag severity-${r.severity.toLowerCase()}`}>
                    {r.severity}
                  </span>
                </td>
                <td>
                  <div>{r.location}</div>
                  <span className="cell-sub">{r.latitude.toFixed(3)}, {r.longitude.toFixed(3)}</span>
                </td>
                <td>
                  {canManageStatus ? (
                    <select
                      className={`status-select ${r.status.toLowerCase().replace(' ', '-')}`}
                      value={r.status}
                      disabled={statusUpdating === r._id}
                      onChange={e => updateStatus(r._id, e.target.value)}
                    >
                      <option value="Reported">Reported</option>
                      <option value="Investigating">Investigating</option>
                      <option value="Cleanup Planned">Cleanup Planned</option>
                      <option value="Resolved">Resolved</option>
                    </select>
                  ) : (
                    <span className={`status status-${r.status.toLowerCase().replace(' ', '-')}`}>
                      {r.status}
                    </span>
                  )}
                </td>
                <td>{new Date(r.reportedAt).toLocaleDateString()}</td>
                <td>
                  <div className="action-buttons-cell">
                    {canDelete && (
                      <button 
                        className="icon-btn danger" 
                        title="Delete incident report (Admin only)"
                        onClick={() => remove(r._id)}
                      >
                        <Trash2 size={16} />
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {rows.length === 0 && <EmptyState text="No pollution reports match your criteria." />}
      </div>

      {/* New Report Modal with Photo Upload & Map Click Instructions */}
      {open && (
        <Modal title="Report Marine Pollution Incident" onClose={() => setOpen(false)}>
          <form className="form-grid" onSubmit={save}>
            <div className="modal-banner-tip">
              <MapPin size={16} />
              <span><strong>Map Pinning:</strong> You can click anywhere on the background map to auto-set coordinates, or type them below.</span>
            </div>

            <label className="span-2">
              Incident Title
              <input 
                type="text"
                value={form.title} 
                onChange={e => setForm({ ...form, title: e.target.value })} 
                placeholder="e.g. Chemical outfall discoloration near creek" 
                required 
              />
            </label>

            <label>
              Pollution Source
              <select value={form.source} onChange={e => setForm({ ...form, source: e.target.value })}>
                <option value="Plastic">Plastic</option>
                <option value="Industrial Discharge">Industrial Discharge</option>
                <option value="Oil Spill">Oil Spill</option>
                <option value="Other">Other</option>
              </select>
            </label>

            <label>
              Severity Level
              <select value={form.severity} onChange={e => setForm({ ...form, severity: e.target.value })}>
                <option value="Low">Low (Localized minor debris)</option>
                <option value="Medium">Medium (Affecting intertidal reach)</option>
                <option value="High">High (Severe ecological hazard)</option>
              </select>
            </label>

            <label className="span-2">
              Location Description
              <input 
                type="text"
                value={form.location} 
                onChange={e => setForm({ ...form, location: e.target.value })} 
                placeholder="e.g. Marina Beach, Section 4" 
                required 
              />
            </label>

            <label>
              Latitude
              <input 
                type="number" 
                step="any" 
                value={form.latitude} 
                onChange={e => setForm({ ...form, latitude: e.target.value })} 
                required 
              />
            </label>

            <label>
              Longitude
              <input 
                type="number" 
                step="any" 
                value={form.longitude} 
                onChange={e => setForm({ ...form, longitude: e.target.value })} 
                required 
              />
            </label>

            <label className="span-2">
              Incident Photographic Evidence URL
              <input 
                type="url"
                value={form.imageUrl} 
                onChange={e => setForm({ ...form, imageUrl: e.target.value })} 
                placeholder="https://example.com/photo.jpg" 
              />
            </label>

            <div className="span-2 sample-photo-picker">
              <span>Quick Photo Presets for Testing:</span>
              <div className="preset-buttons">
                {SAMPLE_IMAGES.map((img, idx) => (
                  <button 
                    key={idx} 
                    type="button" 
                    className="preset-btn"
                    onClick={() => setForm({ ...form, imageUrl: img.url })}
                  >
                    <Camera size={13} /> {img.label}
                  </button>
                ))}
              </div>
            </div>

            <label className="span-2">
              Detailed Environmental Observations
              <textarea 
                rows="3" 
                value={form.description} 
                onChange={e => setForm({ ...form, description: e.target.value })} 
                placeholder="Describe odor, affected marine life, surface extent, and immediate hazard…"
                required 
              />
            </label>

            <div className="modal-actions span-2">
              <button type="button" className="secondary" onClick={() => setOpen(false)}>
                Cancel
              </button>
              <button className="primary" disabled={saving}>
                {saving ? 'Transmitting…' : 'Submit Incident Report'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
